const removeCartItem = function () {
  localStorage.removeItem("shoppingCart");
};
removeCartItem();
